package objetos;

import java.io.IOException;
import java.util.StringTokenizer;

public class ProcessadorBancario {
    private static int numContas = 0;
    private Banco banco;
    public ProcessadorBancario(Banco banco) {
        this.banco = banco;
    }

    public void setBanco(Banco banco) {
        this.banco = banco;
    }

    public String processar(String request) {

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        String comando = null;
        int numConta;
        int contaDestino = 0;
        int valor = 0;

        StringTokenizer tokenizer = new StringTokenizer(request, ";");
        comando = tokenizer.nextToken();

        switch (comando) {
            case "criar":
                try{
                    numConta = Integer.parseInt(tokenizer.nextToken());
                    String nome = tokenizer.nextToken();
                    if (banco.addConta(numConta, nome)) {
                        numContas++;
                        System.out.println("Conta criada com sucesso!");
                        return ("Conta >" + numConta + "< criada com sucesso!");
                    } else {
                        System.out.println("Erro ao criar conta!");
                        return ("Erro de transação: Erro número de conta " + numConta + "já existe.");
                    }
                } catch (Exception e){
                    System.err.println("Erro?: " + request + " " + e.getMessage());
                    return ("Erro de transação: Erro ao cria! " + e.getMessage());
                }

            case "sacar":
                try{
                    numConta = Integer.parseInt(tokenizer.nextToken());
                    valor = Integer.parseInt(tokenizer.nextToken());
                    if (banco.sacar(numConta, valor)) {
                        //System.out.println("Saque realizado com sucesso!");
                        return ("Novo saldo da conta >" + numConta + "< é de " + banco.getSaldo(numConta));
                    } else {
                        //System.out.println("Erro ao sacar!");
                        if(banco.getSaldo(numConta) < valor){
                            return ("Erro de transação: Erro ao sacar, limite não disponível!");
                        }
                        return ("Erro de transação: Erro ao sacar!");
                    }
                } catch (Exception e){
                    System.err.println("Erro?: " + request + " " + e.getMessage());
                    return ("Erro de transação: Erro ao sacar! " + e.getMessage());
                }


            case "depositar":
                try{
                    numConta = Integer.parseInt(tokenizer.nextToken());
                    valor = Integer.parseInt(tokenizer.nextToken());
                    if (banco.depositar(numConta, valor)) {
                        //System.out.println("Depósito realizado com sucesso!");
                        return ("Depósito realizado. Novo saldo da conta >" + numConta + "< é de " + banco.getSaldo(numConta));
                    } else {
                        //System.out.println("Erro ao depositar!");
                        return ("Erro de transação: Erro ao depositar, conta" + numConta + " não existe");
                    }
                } catch (Exception e){
                    System.err.println("Erro?: " + request + " " + e.getMessage());
                    return ("Erro de transação: Erro ao depositar! " + e.getMessage());
                }

            case "saldo":
                try {
                    numConta = Integer.parseInt(tokenizer.nextToken());
                    if (banco.getSaldo(numConta) != -1) {
                        System.out.println("Saldo da conta " + banco.getSaldo(numConta));
                        return ("O saldo da conta é de " + banco.getSaldo(numConta));
                    } else {
                        //System.out.println("Erro ao consultar o saldo!");
                        return ("Erro de transação: Erro ao consultar o saldo");
                    }
                } catch (Exception e){
                    System.err.println("Erro?: " + request + " " + e.getMessage());
                    return ("Erro de transação: Erro ao verificar saldo! " + e.getMessage());
                }

            default:
                return "Erro de transação: Erro comando desconhecido! " + comando;
        }
    }
}